(function() {

    console.log(window.applicationCache);

})();